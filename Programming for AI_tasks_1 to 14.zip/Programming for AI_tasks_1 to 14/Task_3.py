"""
Lab Task 03 — Water Jug Problem  (Depth-First Search)
Given two jugs of known capacity, reach the target volume
in Jug-A using only fill / empty / pour operations.
"""


# --------------------------------------------------------------------------- #
#  Generate legal next states from any (a, b) state
# --------------------------------------------------------------------------- #
def generate_moves(state: tuple, cap_a: int, cap_b: int) -> list[tuple]:
    """
    Return all (new_state, description) pairs reachable in one step.
    Operations:
      0 — Fill Jug-A        1 — Fill Jug-B
      2 — Empty Jug-A       3 — Empty Jug-B
      4 — Pour A → B        5 — Pour B → A
    """
    a, b = state
    candidates = []

    if a < cap_a:
        candidates.append(((cap_a, b), "Fill Jug-A completely"))

    if b < cap_b:
        candidates.append(((a, cap_b), "Fill Jug-B completely"))

    if a > 0:
        candidates.append(((0, b), "Empty Jug-A"))

    if b > 0:
        candidates.append(((a, 0), "Empty Jug-B"))

    if a > 0 and b < cap_b:
        pour_vol = min(a, cap_b - b)
        candidates.append((
            (a - pour_vol, b + pour_vol),
            f"Pour {pour_vol}L from Jug-A into Jug-B"
        ))

    if b > 0 and a < cap_a:
        pour_vol = min(b, cap_a - a)
        candidates.append((
            (a + pour_vol, b - pour_vol),
            f"Pour {pour_vol}L from Jug-B into Jug-A"
        ))

    return candidates


# --------------------------------------------------------------------------- #
#  DFS solver
# --------------------------------------------------------------------------- #
def solve_water_jug(cap_a: int, cap_b: int, goal: int) -> list | None:
    """
    Use an explicit stack (DFS) to find a path from (0, 0) to (goal, *).
    Returns the solution path [(state, action), ...] or None.
    """
    initial  = (0, 0)
    explored = {initial}
    # Each stack frame: (current_state, [(state, action), ...] path so far)
    frontier = [(initial, [(initial, "Start — both jugs empty")])]

    while frontier:
        cur_state, history = frontier.pop()

        if cur_state[0] == goal:
            return history          # success

        for nxt_state, action in generate_moves(cur_state, cap_a, cap_b):
            if nxt_state not in explored:
                explored.add(nxt_state)
                frontier.append((nxt_state, history + [(nxt_state, action)]))

    return None                     # no solution exists


# --------------------------------------------------------------------------- #
#  Pretty-print the solution
# --------------------------------------------------------------------------- #
def display_solution(path: list, cap_a: int, cap_b: int, goal: int) -> None:
    border = "=" * 62
    print(border)
    print("  Water Jug — Depth-First Search Solution")
    print(f"  Jug-A capacity : {cap_a} litres")
    print(f"  Jug-B capacity : {cap_b} litres")
    print(f"  Target volume  : {goal} litres in Jug-A")
    print(border)

    if path is None:
        print("  ✗  No solution exists for these parameters.")
        print(border)
        return

    print(f"\n  {'Step':<5} {'Jug-A':>7} {'Jug-B':>7}   {'Operation'}")
    print("  " + "-" * 54)

    for step, (state, op) in enumerate(path):
        print(f"  {step:<5} {state[0]:>6}L {state[1]:>6}L   {op}")

    print(f"\n  ✓  Reached {goal}L in Jug-A after {len(path)-1} step(s).")
    print(border)


# --------------------------------------------------------------------------- #
#  Entry point
# --------------------------------------------------------------------------- #
if __name__ == "__main__":
    JUG_A   = 4      # litres
    JUG_B   = 3      # litres
    TARGET  = 2      # litres we want in Jug-A

    solution_path = solve_water_jug(JUG_A, JUG_B, TARGET)
    display_solution(solution_path, JUG_A, JUG_B, TARGET)
