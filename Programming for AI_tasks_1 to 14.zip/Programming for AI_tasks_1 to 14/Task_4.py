"""
Lab Task 04 — N-Queens Solver  (Backtracking)
Place N queens on an N×N board so that none attack each other.
"""


# --------------------------------------------------------------------------- #
#  Board state tracker
# --------------------------------------------------------------------------- #
class QueenBoard:
    """
    Keeps track of occupied columns and diagonals while placing queens
    row by row.  'placement[r] = c' means the queen in row r sits in col c.
    """

    def __init__(self, board_size: int):
        self.size      = board_size
        self.placement = []              # column index per row

        # Forbidden sets (updated incrementally — O(1) checks)
        self._occupied_cols  = set()
        self._occupied_diag1 = set()    # row - col  (top-left → bottom-right)
        self._occupied_diag2 = set()    # row + col  (top-right → bottom-left)

        self.all_solutions: list[list[int]] = []

    # ---------------------------------------------------------------- #
    def _is_safe(self, row: int, col: int) -> bool:
        return (
            col not in self._occupied_cols
            and (row - col) not in self._occupied_diag1
            and (row + col) not in self._occupied_diag2
        )

    # ---------------------------------------------------------------- #
    def _place(self, row: int, col: int) -> None:
        self.placement.append(col)
        self._occupied_cols.add(col)
        self._occupied_diag1.add(row - col)
        self._occupied_diag2.add(row + col)

    def _remove(self, row: int, col: int) -> None:
        self.placement.pop()
        self._occupied_cols.discard(col)
        self._occupied_diag1.discard(row - col)
        self._occupied_diag2.discard(row + col)

    # ---------------------------------------------------------------- #
    def _backtrack(self, current_row: int) -> None:
        if current_row == self.size:
            self.all_solutions.append(list(self.placement))
            return

        for try_col in range(self.size):
            if self._is_safe(current_row, try_col):
                self._place(current_row, try_col)
                self._backtrack(current_row + 1)
                self._remove(current_row, try_col)

    def solve(self) -> list[list[int]]:
        self._backtrack(0)
        return self.all_solutions


# --------------------------------------------------------------------------- #
#  Rendering helpers
# --------------------------------------------------------------------------- #
QUEEN = "Q"
EMPTY = "·"

def render_board(arrangement: list[int]) -> str:
    """Return a multi-line string showing the board."""
    n    = len(arrangement)
    sep  = "  +" + "---+" * n
    rows = [sep]
    for r, queen_col in enumerate(arrangement):
        line = "  |"
        for c in range(n):
            line += f" {QUEEN if c == queen_col else EMPTY} |"
        rows += [line, sep]
    rows.append("    " + "  ".join(str(c) for c in range(n)))
    return "\n".join(rows)


def print_step_by_step(arrangement: list[int]) -> None:
    """Show the board after each queen is placed."""
    n     = len(arrangement)
    board = [[EMPTY] * n for _ in range(n)]

    print("\n  ── Step-by-Step Queen Placement ──")
    for step_idx, col in enumerate(arrangement):
        board[step_idx][col] = QUEEN
        sep = "  +" + "---+" * n
        print(f"\n  Step {step_idx + 1}  →  Row {step_idx}, Column {col}")
        print(sep)
        for r in range(step_idx + 1):
            print("  |" + "".join(f" {board[r][c]} |" for c in range(n)))
            print(sep)


# --------------------------------------------------------------------------- #
#  Entry point
# --------------------------------------------------------------------------- #
if __name__ == "__main__":
    N = 6
    print(f"\n{'='*50}")
    print(f"  {N}-Queens Problem — Backtracking Solver")
    print(f"{'='*50}")

    board_solver = QueenBoard(N)
    results      = board_solver.solve()

    print(f"\n  Board size    : {N} × {N}")
    print(f"  Total solutions found : {len(results)}\n")

    for idx, sol in enumerate(results, start=1):
        print(f"\n── Solution {idx} ──")
        print(render_board(sol))

    if results:
        print_step_by_step(results[0])
