"""
Lab Task 06 — Automatic License Plate Recognition (ALPR)
Flask backend: accepts an uploaded image, detects license plates
using OpenCV Haar cascade + contour fallback, optionally reads
characters with pytesseract, and returns annotated results as JSON.
"""

import os
import re
import base64
import urllib.request

import cv2
import numpy as np
from flask import Flask, jsonify, render_template, request

# --------------------------------------------------------------------------- #
app = Flask(__name__)

# --------------------------------------------------------------------------- #
#  Cascade setup — download automatically if missing
# --------------------------------------------------------------------------- #
CASCADE_XML  = "haarcascade_russian_plate_number.xml"
CASCADE_SRC  = (
    "https://raw.githubusercontent.com/opencv/opencv/master/"
    "data/haarcascades/haarcascade_russian_plate_number.xml"
)

if not os.path.isfile(CASCADE_XML):
    print("[→] Downloading Haar cascade …")
    urllib.request.urlretrieve(CASCADE_SRC, CASCADE_XML)
    print("[✓] Cascade downloaded.")

plate_cascade = cv2.CascadeClassifier(CASCADE_XML)


# --------------------------------------------------------------------------- #
#  Helper functions
# --------------------------------------------------------------------------- #
def decode_upload(file_storage) -> np.ndarray | None:
    """Convert a FileStorage object into an OpenCV BGR image."""
    raw_bytes = np.frombuffer(file_storage.read(), dtype=np.uint8)
    return cv2.imdecode(raw_bytes, cv2.IMREAD_COLOR)


def img_to_b64(img: np.ndarray, quality: int = 90) -> str:
    """Encode an OpenCV image to a JPEG base64 string."""
    _, buf = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, quality])
    return base64.b64encode(buf).decode("utf-8")


def enhance_plate_roi(roi: np.ndarray) -> np.ndarray:
    """Upscale, denoise, and binarise a plate region for better OCR."""
    gray   = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
    scaled = cv2.resize(gray, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC)
    blurred = cv2.GaussianBlur(scaled, (3, 3), 0)
    _, thresh = cv2.threshold(
        blurred, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU
    )
    return thresh


def read_plate_text(processed_roi: np.ndarray) -> str:
    """Attempt OCR using pytesseract; gracefully degrade if unavailable."""
    try:
        import pytesseract
        raw = pytesseract.image_to_string(
            processed_roi,
            config=(
                "--psm 8 --oem 3 "
                "-c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
            ),
        )
        cleaned = re.sub(r"[^A-Z0-9\-]", "", raw.upper()).strip()
        return cleaned or "UNREADABLE"
    except Exception:
        return "OCR_NOT_INSTALLED"


def annotate_region(canvas: np.ndarray, x: int, y: int,
                    pw: int, ph: int, label: str, num: int) -> None:
    """Draw bounding box, corner ticks, and label onto the canvas."""
    GREEN  = (0, 220, 110)
    YELLOW = (0, 210, 255)
    BLACK  = (0, 0, 0)

    # Main rectangle
    cv2.rectangle(canvas, (x, y), (x + pw, y + ph), GREEN, 2)

    # Corner ticks (L-shaped)
    tick = 14
    for (cx, cy, sx, sy) in [
        (x,      y,      +1, +1),
        (x + pw, y,      -1, +1),
        (x,      y + ph, +1, -1),
        (x + pw, y + ph, -1, -1),
    ]:
        cv2.line(canvas, (cx, cy), (cx + sx * tick, cy), YELLOW, 2)
        cv2.line(canvas, (cx, cy), (cx, cy + sy * tick), YELLOW, 2)

    # Label badge
    badge_txt = f"#{num} {label}"
    (tw, th), _ = cv2.getTextSize(badge_txt, cv2.FONT_HERSHEY_DUPLEX, 0.52, 1)
    bx, by = x, max(y - 10, th + 6)
    cv2.rectangle(canvas, (bx, by - th - 4), (bx + tw + 8, by + 2), GREEN, -1)
    cv2.putText(canvas, badge_txt, (bx + 4, by - 2),
                cv2.FONT_HERSHEY_DUPLEX, 0.52, BLACK, 1, cv2.LINE_AA)


def contour_fallback(image: np.ndarray) -> list[tuple]:
    """
    When the Haar cascade finds nothing, try a contour-based approach:
    look for horizontally elongated rectangles with plausible plate aspect ratios.
    """
    gray   = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    blur   = cv2.GaussianBlur(gray, (5, 5), 0)
    edges  = cv2.Canny(blur, 40, 130)

    rect_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (15, 3))
    closed = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, rect_kernel)

    contours, _ = cv2.findContours(
        closed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
    )

    candidates = []
    for cnt in contours:
        bx, by, bw, bh = cv2.boundingRect(cnt)
        aspect = bw / max(bh, 1)
        area   = bw * bh
        if 1.8 < aspect < 6.5 and 900 < area < 90_000:
            candidates.append((bx, by, bw, bh))

    return candidates[:5]


# --------------------------------------------------------------------------- #
#  Routes
# --------------------------------------------------------------------------- #
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/detect", methods=["POST"])
def detect():
    uploaded = request.files.get("image")
    if not uploaded:
        return jsonify({"error": "No image provided"}), 400

    img = decode_upload(uploaded)
    if img is None:
        return jsonify({"error": "Could not decode image"}), 400

    # Downscale very large images to keep processing fast
    h, w = img.shape[:2]
    if max(h, w) > 1920:
        factor = 1920 / max(h, w)
        img = cv2.resize(img, (int(w * factor), int(h * factor)))

    # Preprocessing for cascade
    gray_eq = cv2.equalizeHist(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY))

    detections = plate_cascade.detectMultiScale(
        gray_eq,
        scaleFactor=1.05,
        minNeighbors=4,
        minSize=(55, 18),
        maxSize=(420, 160),
    )

    if len(detections) == 0:
        detections = contour_fallback(img)

    output_img = img.copy()
    plate_results = []

    for idx, (rx, ry, rw, rh) in enumerate(detections, start=1):
        roi       = img[ry : ry + rh, rx : rx + rw]
        processed = enhance_plate_roi(roi)
        ocr_text  = read_plate_text(processed)

        annotate_region(output_img, rx, ry, rw, rh, ocr_text, idx)

        _, roi_buf = cv2.imencode(".jpg", roi)
        plate_results.append({
            "id":        idx,
            "text":      ocr_text,
            "x": int(rx), "y": int(ry),
            "w": int(rw), "h": int(rh),
            "plate_img": base64.b64encode(roi_buf).decode(),
        })

    # Summary stamp
    cv2.putText(
        output_img, f"Plates: {len(plate_results)}",
        (10, 34), cv2.FONT_HERSHEY_DUPLEX, 0.9,
        (0, 220, 110), 2, cv2.LINE_AA,
    )

    return jsonify({
        "image":   img_to_b64(output_img),
        "count":   len(plate_results),
        "plates":  plate_results,
        "message": f"Found {len(plate_results)} plate(s)",
    })


# --------------------------------------------------------------------------- #
if __name__ == "__main__":
    app.run(debug=True, port=5000)
