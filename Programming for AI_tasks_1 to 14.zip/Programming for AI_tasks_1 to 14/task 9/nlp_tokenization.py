"""
Lab Task 09 — NLP Tokenization with NLTK
Demonstrates word-level and sentence-level tokenization,
plus stopword filtering and basic frequency counting.
"""

import nltk

# Download required NLTK data (runs once)
for resource in ("punkt", "punkt_tab", "stopwords"):
    nltk.download(resource, quiet=True)

from nltk.tokenize import word_tokenize, sent_tokenize
from nltk.corpus import stopwords
from collections import Counter


# --------------------------------------------------------------------------- #
SAMPLE_TEXT = (
    "Artificial Intelligence is rapidly changing the world. "
    "Machine learning, a subset of AI, enables computers to learn "
    "from data without being explicitly programmed. "
    "Natural Language Processing allows machines to understand human speech."
)

STOP_WORDS = set(stopwords.words("english"))

# --------------------------------------------------------------------------- #
def tokenize_sentences(text: str) -> list[str]:
    return sent_tokenize(text)

def tokenize_words(text: str) -> list[str]:
    return word_tokenize(text)

def filter_tokens(tokens: list[str]) -> list[str]:
    """Keep only alphabetical tokens that are not stopwords."""
    return [
        tok.lower()
        for tok in tokens
        if tok.isalpha() and tok.lower() not in STOP_WORDS
    ]

def top_words(tokens: list[str], n: int = 5) -> list[tuple[str, int]]:
    return Counter(tokens).most_common(n)


# --------------------------------------------------------------------------- #
if __name__ == "__main__":
    print("=" * 55)
    print("  NLP Tokenization Demo")
    print("=" * 55)

    print("\n[Original Text]")
    print(SAMPLE_TEXT)

    sentences = tokenize_sentences(SAMPLE_TEXT)
    print(f"\n[Sentence Tokens]  ({len(sentences)} sentences)")
    for i, sent in enumerate(sentences, 1):
        print(f"  {i}. {sent}")

    all_tokens = tokenize_words(SAMPLE_TEXT)
    print(f"\n[Word Tokens]  ({len(all_tokens)} tokens)")
    print(" ", all_tokens)

    meaningful = filter_tokens(all_tokens)
    print(f"\n[Meaningful Tokens — stopwords removed]  ({len(meaningful)} tokens)")
    print(" ", meaningful)

    print(f"\n[Top-5 Most Frequent Words]")
    for word, freq in top_words(meaningful):
        print(f"  {word:<20} {freq} time(s)")

    print("=" * 55)
