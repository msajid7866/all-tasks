"""
Lab Task 10 — University Admission Chatbot  (Flask)
A keyword-driven rule-based chatbot that answers
common admission queries via a web interface.
"""

from flask import Flask, jsonify, render_template, request

app = Flask(__name__)

# --------------------------------------------------------------------------- #
#  Knowledge base — keyword → answer
# --------------------------------------------------------------------------- #
KB: list[tuple[list[str], str]] = [
    (
        ["admission", "apply", "open", "enroll"],
        "Admissions for Fall 2026 are currently open. Visit our portal to begin your application.",
    ),
    (
        ["deadline", "last date", "due date", "closing"],
        "The application deadline is 30 August 2026. Late applications are not accepted.",
    ),
    (
        ["program", "degree", "course", "major", "bscs", "bsai", "bsit", "bba"],
        "We offer BSCS, BSAI, BSIT, and BBA programmes. Each is four years long.",
    ),
    (
        ["fee", "cost", "tuition", "charges", "semester"],
        "The average semester fee is PKR 85,000. Instalments are available.",
    ),
    (
        ["scholarship", "financial aid", "grant", "merit"],
        "Merit-based scholarships are awarded to students with high entry-test scores.",
    ),
    (
        ["hostel", "accommodation", "dormitory", "residence"],
        "On-campus hostels are available for both male and female students.",
    ),
    (
        ["contact", "email", "phone", "reach", "helpdesk"],
        "Reach our admissions office at admissions@university.edu or call +92-42-111-000-111.",
    ),
    (
        ["hello", "hi", "hey", "salam"],
        "Hello! I am the University Admissions Assistant. Ask me anything about admissions.",
    ),
]


def find_answer(user_input: str) -> str:
    """Search the knowledge base and return the best matching answer."""
    text = user_input.lower()
    for keywords, reply in KB:
        if any(kw in text for kw in keywords):
            return reply
    return "I'm not sure about that. Please contact admissions@university.edu for more details."


# --------------------------------------------------------------------------- #
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/chat", methods=["POST"])
def chat():
    payload = request.get_json(silent=True) or {}
    user_msg = (payload.get("message") or "").strip()
    if not user_msg:
        return jsonify({"reply": "Please type a message."}), 400
    return jsonify({"reply": find_answer(user_msg)})


# --------------------------------------------------------------------------- #
if __name__ == "__main__":
    app.run(debug=True)
