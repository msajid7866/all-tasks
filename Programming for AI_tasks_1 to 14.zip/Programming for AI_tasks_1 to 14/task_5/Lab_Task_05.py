"""
Lab Task 05 — Image Processing with OpenCV
Demonstrates a pipeline of computer-vision operations
on a single source image.
"""

import sys
import cv2
import numpy as np
import matplotlib.pyplot as plt


# --------------------------------------------------------------------------- #
#  Utility
# --------------------------------------------------------------------------- #
def load_image(path: str) -> np.ndarray:
    img = cv2.imread(path)
    if img is None:
        sys.exit(f"[✗] Cannot open image: {path}")
    print(f"[✓] Loaded  {path}  ({img.shape[1]}×{img.shape[0]} px)")
    return img


def display(img: np.ndarray, title: str, grayscale: bool = False) -> None:
    """Render one image in a matplotlib window."""
    plt.figure(figsize=(6, 5))
    plt.title(title, fontsize=13)
    plt.axis("off")
    if grayscale:
        plt.imshow(img, cmap="gray")
    else:
        plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    plt.tight_layout()
    plt.show()


# --------------------------------------------------------------------------- #
#  Processing pipeline
# --------------------------------------------------------------------------- #
def run_pipeline(src: np.ndarray) -> None:

    # 1. Original
    display(src, "01 — Original")

    # 2. Grayscale conversion
    gray = cv2.cvtColor(src, cv2.COLOR_BGR2GRAY)
    display(gray, "02 — Grayscale", grayscale=True)

    # 3. Gaussian smoothing (reduces high-frequency noise)
    kernel_sz = (7, 7)
    smoothed  = cv2.GaussianBlur(gray, kernel_sz, sigmaX=0)
    display(smoothed, "03 — Gaussian Blur (7×7)", grayscale=True)

    # 4. Canny edge detection
    edges = cv2.Canny(smoothed, threshold1=80, threshold2=160)
    display(edges, "04 — Canny Edges", grayscale=True)

    # 5. Binary thresholding
    _, binary = cv2.threshold(gray, thresh=120, maxval=255,
                              type=cv2.THRESH_BINARY)
    display(binary, "05 — Binary Threshold (T=120)", grayscale=True)

    # 6. Resize to fixed dimensions
    thumbnail = cv2.resize(src, dsize=(200, 200),
                           interpolation=cv2.INTER_LINEAR)
    display(thumbnail, "06 — Resized 200×200 px")

    # 7. Central crop (middle 50 % of each dimension)
    h, w = src.shape[:2]
    y0, y1 = int(h * 0.25), int(h * 0.75)
    x0, x1 = int(w * 0.25), int(w * 0.75)
    cropped = src[y0:y1, x0:x1]
    display(cropped, "07 — Centre Crop (50 %)")

    # 8. Shape annotations
    annotated = src.copy()
    cv2.line(annotated,      (20, 20),    (320, 20),    (34, 197, 94), 2)
    cv2.rectangle(annotated, (40, 40),    (280, 280),   (59, 130, 246), 3)
    cv2.circle(annotated,    (w//2, h//2), min(w, h)//5, (239, 68, 68),  3)
    display(annotated, "08 — Line / Rectangle / Circle")

    # 9. Text watermark
    watermarked = src.copy()
    cv2.putText(
        watermarked, "OpenCV Lab",
        org=(40, 60),
        fontFace=cv2.FONT_HERSHEY_SIMPLEX,
        fontScale=1.2,
        color=(255, 230, 0),
        thickness=2,
        lineType=cv2.LINE_AA,
    )
    display(watermarked, "09 — Text Watermark")

    # 10. Horizontal flip
    flipped = cv2.flip(src, flipCode=1)
    display(flipped, "10 — Horizontal Mirror")

    # 11. 45° rotation around image centre
    centre  = (w // 2, h // 2)
    rot_mat = cv2.getRotationMatrix2D(centre, angle=45.0, scale=1.0)
    rotated = cv2.warpAffine(src, rot_mat, (w, h),
                             borderMode=cv2.BORDER_CONSTANT,
                             borderValue=(0, 0, 0))
    display(rotated, "11 — Rotated 45°")

    # Save edge map as output
    out_path = "edges_result.jpg"
    cv2.imwrite(out_path, edges)
    print(f"[✓] Edge map saved → {out_path}")


# --------------------------------------------------------------------------- #
#  Entry point
# --------------------------------------------------------------------------- #
if __name__ == "__main__":
    IMAGE_PATH = r"C:\Users\anssa\Downloads\Task_5\Screenshot 2026-03-07 225657.png"
    source_img = load_image(IMAGE_PATH)
    run_pipeline(source_img)
