"""
Lab Task 07 — Pakistan Weather API  (Flask + OpenWeatherMap)
Endpoints:
  GET /weather          ?city=&time=  → slot-based forecast
  GET /weather/day      ?city=        → full-day breakdown
  GET /weather/now      ?city=        → current conditions
  GET /cities                         → list of supported cities
"""

from datetime import datetime, timedelta, timezone
from flask import Flask, jsonify, request
import requests

app = Flask(__name__)

# --------------------------------------------------------------------------- #
OWM_KEY  = "18699046af8113add3859f8fad3932d0"
OWM_URL  = "https://api.openweathermap.org/data/2.5"
PKT      = timezone(timedelta(hours=5))          # Pakistan Standard Time

CITY_ROSTER = [
    "Lahore", "Karachi", "Islamabad", "Rawalpindi", "Peshawar",
    "Quetta", "Multan", "Faisalabad", "Hyderabad", "Sialkot",
    "Gujranwala", "Bahawalpur", "Sargodha", "Abbottabad", "Murree",
]

DAY_PERIODS = {
    "morning":   range(5,  12),
    "afternoon": range(12, 17),
    "evening":   range(17, 21),
    "night":     list(range(21, 24)) + list(range(0, 5)),
}

# --------------------------------------------------------------------------- #
#  Helper utilities
# --------------------------------------------------------------------------- #
def hour_to_period(hour: int) -> str:
    for period, hours in DAY_PERIODS.items():
        if hour in hours:
            return period
    return "night"


def build_condition_summary(condition: str, desc: str,
                            humidity: int, wind_kph: int,
                            rain_prob: int = 0) -> str:
    """Human-readable one-liner about the weather."""
    cond_lc = condition.lower()
    qualifiers = []

    if "thunderstorm" in cond_lc:
        base = "Thunderstorm likely"
    elif "drizzle" in cond_lc:
        base = "Light drizzle"
    elif "rain" in cond_lc or rain_prob > 60:
        base = "Rain expected"
    elif rain_prob > 30:
        base = "Chance of light rain"
    elif "snow" in cond_lc:
        base = "Snowfall"
    elif any(w in cond_lc for w in ("mist", "fog", "haze", "smoke")):
        base = "Low visibility — mist/fog"
    elif "clear" in cond_lc:
        base = "Clear sky"
    elif "cloud" in cond_lc:
        base = "Partly cloudy" if any(w in desc for w in ("few", "scat")) else "Overcast"
    else:
        base = desc.title()

    if humidity >= 80:
        qualifiers.append("very humid")
    elif humidity >= 65:
        qualifiers.append("humid")

    if wind_kph >= 35:
        qualifiers.append("strong winds")
    elif wind_kph >= 18:
        qualifiers.append("moderate wind")

    return base + (" · " + " · ".join(qualifiers) if qualifiers else "")


def owm_forecast(city: str) -> requests.Response:
    return requests.get(
        f"{OWM_URL}/forecast",
        params={"q": f"{city},PK", "appid": OWM_KEY, "units": "metric", "cnt": 40},
        timeout=8,
    )


def parse_entry(entry: dict) -> tuple[datetime, dict]:
    """Convert one OWM forecast list item into (local_datetime, info_dict)."""
    utc_dt    = datetime.fromtimestamp(entry["dt"], tz=timezone.utc)
    local_dt  = utc_dt.astimezone(PKT)
    wx        = entry["weather"][0]
    wind_kph  = round(entry["wind"]["speed"] * 3.6)
    rain_pct  = round(entry.get("pop", 0) * 100)

    info = {
        "date":        local_dt.strftime("%A, %d %b"),
        "time":        local_dt.strftime("%I:%M %p"),
        "temperature": round(entry["main"]["temp"]),
        "feels_like":  round(entry["main"]["feels_like"]),
        "humidity":    entry["main"]["humidity"],
        "condition":   wx["main"],
        "description": wx["description"].title(),
        "wind_kph":    wind_kph,
        "rain_chance": rain_pct,
        "summary":     build_condition_summary(
            wx["main"], wx["description"],
            entry["main"]["humidity"], wind_kph, rain_pct
        ),
    }
    return local_dt, info


# --------------------------------------------------------------------------- #
#  Routes
# --------------------------------------------------------------------------- #
@app.route("/cities")
def list_cities():
    return jsonify({"supported_cities": CITY_ROSTER})


@app.route("/weather")
def weather_by_period():
    city   = request.args.get("city", "Lahore").strip().title()
    period = request.args.get("time", "morning").strip().lower()

    if period not in DAY_PERIODS:
        return jsonify({"error": f"Invalid time period '{period}'"}), 400

    resp = owm_forecast(city)
    if resp.status_code != 200:
        return jsonify({"error": "City not found or API error"}), 404

    data    = resp.json()
    matches = []
    for entry in data["list"]:
        local_dt, info = parse_entry(entry)
        if hour_to_period(local_dt.hour) == period:
            matches.append(info)

    return jsonify({
        "city":    data["city"]["name"],
        "country": "Pakistan",
        "period":  period,
        "entries": matches,
    })


@app.route("/weather/day")
def weather_full_day():
    city = request.args.get("city", "Lahore").strip().title()
    resp = owm_forecast(city)
    if resp.status_code != 200:
        return jsonify({"error": "City not found or API error"}), 404

    data     = resp.json()
    days: dict[str, dict] = {}

    for entry in data["list"]:
        local_dt, info = parse_entry(entry)
        day_key        = local_dt.strftime("%A, %d %b")
        period         = hour_to_period(local_dt.hour)

        days.setdefault(day_key, {})
        if period not in days[day_key]:
            days[day_key][period] = info

    structured = [
        {
            "date":      day,
            "morning":   slots.get("morning",   "No data"),
            "afternoon": slots.get("afternoon", "No data"),
            "evening":   slots.get("evening",   "No data"),
            "night":     slots.get("night",     "No data"),
        }
        for day, slots in days.items()
    ]

    return jsonify({
        "city":    data["city"]["name"],
        "country": "Pakistan",
        "days":    structured,
    })


@app.route("/weather/now")
def weather_current():
    city = request.args.get("city", "Lahore").strip().title()
    resp = requests.get(
        f"{OWM_URL}/weather",
        params={"q": f"{city},PK", "appid": OWM_KEY, "units": "metric"},
        timeout=8,
    )
    if resp.status_code != 200:
        return jsonify({"error": "City not found or API error"}), 404

    data     = resp.json()
    now_pkt  = datetime.now(PKT)
    wx       = data["weather"][0]
    wind_kph = round(data["wind"]["speed"] * 3.6)

    return jsonify({
        "city":          data["name"],
        "country":       "Pakistan",
        "local_time":    now_pkt.strftime("%I:%M %p"),
        "period":        hour_to_period(now_pkt.hour),
        "temperature":   round(data["main"]["temp"]),
        "feels_like":    round(data["main"]["feels_like"]),
        "humidity":      data["main"]["humidity"],
        "condition":     wx["main"],
        "description":   wx["description"].title(),
        "wind_kph":      wind_kph,
        "visibility_km": round(data.get("visibility", 0) / 1000, 1),
        "summary":       build_condition_summary(
            wx["main"], wx["description"],
            data["main"]["humidity"], wind_kph
        ),
    })


# --------------------------------------------------------------------------- #
if __name__ == "__main__":
    app.run(debug=True, port=5000)
