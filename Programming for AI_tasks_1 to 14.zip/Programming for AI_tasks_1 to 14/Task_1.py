"""
Lab Task 01 — Web Email Harvester
Scrapes a webpage, pulls out all email addresses,
and stores them in an Excel file.
"""

import re
import requests
from bs4 import BeautifulSoup
import openpyxl


# --------------------------------------------------------------------------- #
#  Fetch raw page content
# --------------------------------------------------------------------------- #
def grab_page_text(site_url: str) -> str:
    """Download the page and return its visible text."""
    headers = {"User-Agent": "Mozilla/5.0 (EmailBot/1.0)"}
    resp = requests.get(site_url, headers=headers, timeout=10)
    resp.raise_for_status()

    soup = BeautifulSoup(resp.content, "html.parser")
    # Remove script/style noise before extracting text
    for tag in soup(["script", "style"]):
        tag.decompose()

    return soup.get_text(separator=" ")


# --------------------------------------------------------------------------- #
#  Parse emails from plain text
# --------------------------------------------------------------------------- #
MAIL_REGEX = re.compile(
    r"[a-zA-Z0-9][a-zA-Z0-9._%+\-]*"   # local part
    r"@"
    r"[a-zA-Z0-9.\-]+"                 # domain name
    r"\.[a-zA-Z]{2,}"                  # top-level domain
)

def harvest_emails(raw_text: str) -> list[str]:
    """Return a sorted, deduplicated list of email addresses found."""
    matches = MAIL_REGEX.findall(raw_text)
    unique  = sorted(set(m.lower() for m in matches))
    return unique


# --------------------------------------------------------------------------- #
#  Write results to Excel
# --------------------------------------------------------------------------- #
def dump_to_excel(mail_list: list[str], filename: str = "emails.xlsx") -> None:
    """Save every email on its own row under a header."""
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Harvested Emails"

    # Header row — bold
    header_cell = ws.cell(row=1, column=1, value="Email Address")
    header_cell.font = openpyxl.styles.Font(bold=True)

    for row_idx, addr in enumerate(mail_list, start=2):
        ws.cell(row=row_idx, column=1, value=addr)

    # Auto-fit column width
    ws.column_dimensions["A"].width = max(
        (len(a) for a in mail_list), default=20
    ) + 4

    wb.save(filename)
    print(f"[✓] Saved {len(mail_list)} email(s) → {filename}")


# --------------------------------------------------------------------------- #
#  Entry point
# --------------------------------------------------------------------------- #
if __name__ == "__main__":
    target_url = input("Enter the website URL to scan: ").strip()

    print(f"[→] Fetching: {target_url}")
    page_content = grab_page_text(target_url)

    found = harvest_emails(page_content)
    print(f"[✓] Discovered {len(found)} unique email(s)")

    dump_to_excel(found)
