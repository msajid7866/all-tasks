/* ── Element refs ─────────────────────────────────────────── */
const cityField    = document.getElementById('cityField');
const goBtn        = document.getElementById('goBtn');
const errorBanner  = document.getElementById('errorBanner');
const loadingBlock = document.getElementById('loadingBlock');
const weatherBlock = document.getElementById('weatherBlock');
const forecastRow  = document.getElementById('forecastRow');

/* ── Display helpers ─────────────────────────────────────── */
function showBanner(msg) {
  errorBanner.textContent = msg;
  errorBanner.classList.remove('hidden');
  weatherBlock.classList.add('hidden');
  loadingBlock.classList.add('hidden');
}

function hideBanner() { errorBanner.classList.add('hidden'); }

function setLoading(active) {
  if (active) {
    loadingBlock.classList.remove('hidden');
    weatherBlock.classList.add('hidden');
    hideBanner();
  } else {
    loadingBlock.classList.add('hidden');
  }
}

function fill(id, value) { document.getElementById(id).textContent = value; }

/* ── Populate UI with API data ───────────────────────────── */
function renderWeather(data) {
  fill('cityLabel',    data.city);
  fill('countryLabel', data.country);
  fill('tempVal',      data.temp);
  fill('feelsVal',     `${data.feels_like}°C`);
  fill('humidVal',     `${data.humidity}%`);
  fill('windVal',      `${data.wind_speed} km/h`);
  fill('pressVal',     `${data.pressure} hPa`);
  fill('wxDesc',       data.description);
  fill('mainIcon',     data.icon);

  /* 5-day forecast strip */
  forecastRow.innerHTML = '';
  (data.forecast || []).forEach(day => {
    const card = document.createElement('div');
    card.className = 'fc-card';
    card.innerHTML =
      `<span class="fc-day">${day.day}</span>` +
      `<span class="fc-icon">${day.icon}</span>` +
      `<span class="fc-temp">${day.temp}°C</span>`;
    forecastRow.appendChild(card);
  });

  weatherBlock.classList.remove('hidden');
}

/* ── Fetch from Flask backend ────────────────────────────── */
async function loadWeather(city) {
  if (!city) { showBanner('Please type a city name.'); return; }

  setLoading(true);
  try {
    const res  = await fetch(`/weather?city=${encodeURIComponent(city)}`);
    const json = await res.json();

    if (!res.ok) { showBanner(json.error || 'Something went wrong.'); return; }

    renderWeather(json);
  } catch {
    showBanner('Network error — is Flask running?');
  } finally {
    setLoading(false);
  }
}

/* ── Events ──────────────────────────────────────────────── */
goBtn.addEventListener('click', () => loadWeather(cityField.value.trim()));
cityField.addEventListener('keydown', e => { if (e.key === 'Enter') goBtn.click(); });

/* Load default city on startup */
window.addEventListener('DOMContentLoaded', () => loadWeather('Lahore'));
