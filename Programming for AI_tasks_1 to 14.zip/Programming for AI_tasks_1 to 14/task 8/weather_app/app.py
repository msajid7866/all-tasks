"""
Lab Task 08 — Weather App  (Flask + OpenWeatherMap)
Serves an HTML frontend and provides a /weather endpoint that
returns current conditions + 5-day forecast as JSON.
"""

from datetime import datetime
from flask import Flask, jsonify, render_template, request
import requests

app = Flask(__name__)

OWM_API_KEY  = "7283761b406f871484b51ee4b459979c"
OWM_BASE_URL = "https://api.openweathermap.org/data/2.5"

# Map OWM condition names to emojis
CONDITION_ICONS = {
    "Clear":        "☀️",
    "Clouds":       "⛅",
    "Rain":         "🌧️",
    "Drizzle":      "🌦️",
    "Thunderstorm": "⛈️",
    "Snow":         "❄️",
    "Mist":         "🌫️",
    "Fog":          "🌫️",
    "Haze":         "🌫️",
    "Smoke":        "🌫️",
}

def condition_emoji(cond_name: str) -> str:
    return CONDITION_ICONS.get(cond_name, "🌡️")


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/weather")
def get_weather():
    city_name = request.args.get("city", "").strip()
    if not city_name:
        return jsonify({"error": "Please provide a city name."}), 400

    # --- Current weather ---------------------------------------------------
    cur_resp = requests.get(
        f"{OWM_BASE_URL}/weather",
        params={"q": city_name, "appid": OWM_API_KEY, "units": "metric"},
        timeout=6,
    )

    if cur_resp.status_code == 404:
        return jsonify({"error": f"'{city_name}' not found."}), 404
    if not cur_resp.ok:
        return jsonify({"error": "Weather service unavailable."}), 500

    cur = cur_resp.json()

    # --- 5-day forecast (pick 12:00 readings) ------------------------------
    fore_resp = requests.get(
        f"{OWM_BASE_URL}/forecast",
        params={"q": city_name, "appid": OWM_API_KEY, "units": "metric", "cnt": 40},
        timeout=6,
    )

    forecast_list = []
    if fore_resp.ok:
        recorded_dates = set()
        for slot in fore_resp.json()["list"]:
            slot_date, slot_time = slot["dt_txt"].split()
            if slot_time == "12:00:00" and slot_date not in recorded_dates:
                recorded_dates.add(slot_date)
                day_abbr = datetime.strptime(slot_date, "%Y-%m-%d").strftime("%a")
                forecast_list.append({
                    "day":  day_abbr,
                    "temp": round(slot["main"]["temp"]),
                    "icon": condition_emoji(slot["weather"][0]["main"]),
                    "desc": slot["weather"][0]["description"],
                })
            if len(forecast_list) == 5:
                break

    payload = {
        "city":        cur["name"],
        "country":     cur["sys"]["country"],
        "temp":        round(cur["main"]["temp"]),
        "feels_like":  round(cur["main"]["feels_like"]),
        "humidity":    cur["main"]["humidity"],
        "pressure":    cur["main"]["pressure"],
        "wind_speed":  round(cur["wind"]["speed"] * 3.6),   # m/s → km/h
        "description": cur["weather"][0]["description"],
        "condition":   cur["weather"][0]["main"],
        "icon":        condition_emoji(cur["weather"][0]["main"]),
        "forecast":    forecast_list,
    }
    return jsonify(payload)


if __name__ == "__main__":
    app.run(debug=True)
